if ($(window).width() < 767) {
  $('#carousel').removeClass('.visible');
}

$(".visible").owlCarousel({

  loop: true,
  margin: 10,
  dots: false,
  nav: false,
  autoplay: true,
  responsive: {
    0: {
      items: 1,
      nav: true,
    },
    600: {
      items: 2
    },
    991: {
      items: 1,
    },
    1024: {
      items: 2,
    },
    1100: {
      items: 2,
    },
    1200: {
      items: 3
    }
  }

});


// loader script start
$(window).on('load', function () {
  setTimeout(function () { // allowing 3 secs to fade out loader
    $('.page-loader').fadeOut('slow');
  }, 800);
});
// loader script end

/* Open the sidenav */
function openNav() {
  document.getElementById("mySidenav").style.left = "0%";
}
/* Close/hide the sidenav */
function closeNav() {
  document.getElementById("mySidenav").style.left = "-100%";
}
// slider
// $('.owl-carousel').owlCarousel({
//   loop: true,
//   margin: 10,
//   dots: false,
//   nav: false,
//   // autoplay: true,
//   responsive: {
//     0: {
//       items: 1,
//       nav: true,
//     },
//     600: {
//       items: 2
//     },
//     991: {
//       items: 1,
//     },
//     1024: {
//       items: 2,
//     },
//     1100: {
//       items: 2,
//     },
//     1200: {
//       items: 3
//     }
//   }
// })

